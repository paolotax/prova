(() => {
  "use strict";

  let currentChatName = "";

  // Osserva cambi di chat e inserisce il bottone
  function init() {
    const observer = new MutationObserver(() => {
      tryInsertButton();
    });

    observer.observe(document.body, { childList: true, subtree: true });
    tryInsertButton();
  }

  function tryInsertButton() {
    // Header della chat attiva dentro #main
    const header = document.querySelector("#main header");
    if (!header) {
      // Nessuna chat aperta — rimuovi bottone
      document.querySelectorAll(".scagnozz-btn").forEach((el) => el.remove());
      currentChatName = "";
      return;
    }

    // Nome contatto: span[dir="auto"] o span[title] (fallback)
    const nameSpan =
      header.querySelector('span[dir="auto"]') ||
      header.querySelector("span[title]");
    if (!nameSpan) return;

    const chatName =
      nameSpan.getAttribute("title") || nameSpan.textContent.trim();
    if (!chatName) return;

    // Se il bottone è già presente per questa chat, non fare nulla
    if (chatName === currentChatName && document.querySelector(".scagnozz-btn"))
      return;

    // Rimuovi vecchio bottone se cambio chat
    document.querySelectorAll(".scagnozz-btn").forEach((el) => el.remove());

    currentChatName = chatName;

    const btn = document.createElement("button");
    btn.className = "scagnozz-btn";
    btn.textContent = "📋 Scagnozz";
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      openForm();
    });

    // Bottone floating fisso — sempre visibile
    document.body.appendChild(btn);
  }

  // Estrai il numero di telefono dalla pagina
  function extractPhoneNumber() {
    // Prova dal nome della chat (per contatti non salvati mostra il numero)
    if (/^\+?\d[\d\s-]{7,}$/.test(currentChatName.replace(/\s/g, ""))) {
      return currentChatName.replace(/[\s-]/g, "");
    }

    // Cerca il numero nel pannello info contatto (section) se aperto
    const sections = document.querySelectorAll("section");
    for (const section of sections) {
      for (const span of section.querySelectorAll("span")) {
        const text = (span.textContent || "").trim();
        if (/^\+\d[\d\s-]{7,}$/.test(text) && text.length < 25) {
          return text.replace(/[\s-]/g, "");
        }
      }
    }

    return "";
  }

  // Estrai gli ultimi messaggi dalla chat
  function extractRecentMessages(count = 5) {
    const messages = [];
    const msgElements = document.querySelectorAll(
      'div.message-in span.selectable-text, div[data-pre-plain-text] span.selectable-text'
    );

    const recent = Array.from(msgElements).slice(-count);
    for (const el of recent) {
      const text = el.textContent?.trim();
      if (text) messages.push(text);
    }

    return messages.join("\n\n");
  }

  // Apri il mini-form
  function openForm() {
    // Rimuovi form esistente
    document.querySelectorAll(".scagnozz-overlay").forEach((el) => el.remove());

    const phone = extractPhoneNumber();
    const recentMsgs = extractRecentMessages();

    const overlay = document.createElement("div");
    overlay.className = "scagnozz-overlay";
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) overlay.remove();
    });

    const form = document.createElement("div");
    form.className = "scagnozz-form";
    form.innerHTML = `
      <h3>📋 Salva su Scagnozz</h3>
      <div id="scagnozz-status-msg" class="scagnozz-status" style="display:none"></div>

      <label>Nome</label>
      <input type="text" id="scagnozz-nome" value="${escapeAttr(currentChatName)}">

      <label>Telefono</label>
      <input type="tel" id="scagnozz-telefono" value="${escapeAttr(phone)}">

      <label>Scuola</label>
      <input type="text" id="scagnozz-scuola" placeholder="Nome scuola...">

      <label>Classe</label>
      <input type="text" id="scagnozz-classe" placeholder="Es. 2A">

      <label>Messaggio</label>
      <textarea id="scagnozz-messaggio">${escapeHtml(recentMsgs)}</textarea>

      <div class="scagnozz-form-actions">
        <button class="scagnozz-cancel" id="scagnozz-cancel-btn">Annulla</button>
        <button class="scagnozz-save" id="scagnozz-save-btn">Salva</button>
      </div>
    `;

    overlay.appendChild(form);
    document.body.appendChild(overlay);

    // Focus sul campo scuola (nome e telefono sono già compilati)
    setTimeout(() => document.getElementById("scagnozz-scuola")?.focus(), 100);

    document
      .getElementById("scagnozz-cancel-btn")
      .addEventListener("click", () => overlay.remove());

    document
      .getElementById("scagnozz-save-btn")
      .addEventListener("click", () => submitForm(overlay));
  }

  // Invia i dati all'API
  async function submitForm(overlay) {
    const saveBtn = document.getElementById("scagnozz-save-btn");
    const statusDiv = document.getElementById("scagnozz-status-msg");
    saveBtn.disabled = true;
    saveBtn.textContent = "Invio...";

    const data = {
      nome: document.getElementById("scagnozz-nome").value.trim(),
      telefono: document.getElementById("scagnozz-telefono").value.trim(),
      scuola_nome: document.getElementById("scagnozz-scuola").value.trim(),
      classe: document.getElementById("scagnozz-classe").value.trim(),
      messaggio: document.getElementById("scagnozz-messaggio").value.trim(),
    };

    chrome.runtime.sendMessage(
      { action: "postToScagnozz", data },
      (result) => {
        if (result && result.success) {
          showStatus(
            statusDiv,
            `Salvato! ${result.persona_nome}${result.scuola_nome ? " - " + result.scuola_nome : ""}`,
            "success"
          );
          setTimeout(() => overlay.remove(), 1500);
        } else {
          showStatus(
            statusDiv,
            (result && result.error) || "Errore nel salvataggio",
            "error"
          );
          saveBtn.disabled = false;
          saveBtn.textContent = "Salva";
        }
      }
    );
  }

  function showStatus(el, msg, type) {
    el.textContent = msg;
    el.className = `scagnozz-status ${type}`;
    el.style.display = "block";
  }

  function escapeAttr(str) {
    return str
      .replace(/&/g, "&amp;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function escapeHtml(str) {
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  // Avvia quando la pagina è pronta
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
