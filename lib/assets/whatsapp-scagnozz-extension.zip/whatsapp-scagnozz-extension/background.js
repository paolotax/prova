// Background service worker - gestisce le chiamate API
// per evitare problemi CORS dal content script

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "postToScagnozz") {
    chrome.storage.sync.get(["apiUrl", "apiToken"], async (settings) => {
      if (!settings.apiUrl || !settings.apiToken) {
        sendResponse({ error: "Configura URL e Token nelle impostazioni dell'estensione" });
        return;
      }

      const data = { ...request.data, api_key: settings.apiToken };

      try {
        const response = await fetch(settings.apiUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        });

        const result = await response.json();

        if (response.ok && result.success) {
          sendResponse({ success: true, ...result });
        } else {
          sendResponse({ error: result.error || "Errore nel salvataggio" });
        }
      } catch (err) {
        sendResponse({ error: "Errore di connessione: " + err.message });
      }
    });

    // Return true to indicate async response
    return true;
  }
});
