document.addEventListener("DOMContentLoaded", () => {
  const apiUrl = document.getElementById("apiUrl");
  const apiToken = document.getElementById("apiToken");
  const saveBtn = document.getElementById("saveBtn");
  const status = document.getElementById("status");

  // Carica impostazioni salvate
  chrome.storage.sync.get(["apiUrl", "apiToken"], (data) => {
    if (data.apiUrl) apiUrl.value = data.apiUrl;
    if (data.apiToken) apiToken.value = data.apiToken;
  });

  saveBtn.addEventListener("click", () => {
    const url = apiUrl.value.trim();
    const token = apiToken.value.trim();

    if (!url || !token) {
      status.textContent = "Compila tutti i campi";
      status.className = "status error";
      return;
    }

    chrome.storage.sync.set({ apiUrl: url, apiToken: token }, () => {
      status.textContent = "Impostazioni salvate!";
      status.className = "status success";
      setTimeout(() => { status.className = "status"; }, 2000);
    });
  });
});
